#include <iostream>
#include <pigpio.h>

void gpioCallback(int gpio, int level, uint32_t tick) {
    if (level == PI_TIMEOUT) return;

    std::cout << "GPIO " << gpio << " changed to " << (level == 1 ? "HIGH" : "LOW") << std::endl;
}

int main() {
    if (gpioInitialise() < 0) {
        std::cerr << "pigpio initialisation failed." << std::endl;
        return 1;
    }

    const int gpioPins[] = {23, 26};

    for (int gpio : gpioPins) {
        gpioSetMode(gpio, PI_INPUT);
        gpioSetPullUpDown(gpio, PI_PUD_UP); // optional depending on wiring
        gpioSetAlertFunc(gpio, gpioCallback);
    }

    std::cout << "Monitoring GPIO 24 and 26 for changes. Press Ctrl+C to quit." << std::endl;

    while (true) {
        time_sleep(1); // keep program running
    }

    gpioTerminate();
    return 0;
}
